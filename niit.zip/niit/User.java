package com.niit;

public class User {
   private int UserId;
   private String  UserName;
    private String  Passwords;
    private String  emailId;
    private String  PhoneNo;

    public User(){

    }

    public User(int userId, String userName, String passwords, String emailId, String phoneNo) {
        UserId = userId;
        UserName = userName;
        Passwords = passwords;
        this.emailId = emailId;
        PhoneNo = phoneNo;
    }


    public int getUserId() {
        return UserId;
    }

    public void setUserId(int userId) {
        UserId = userId;
    }

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String userName) {
        UserName = userName;
    }

    public String getPasswords() {
        return Passwords;
    }

    public void setPasswords(String passwords) {
        Passwords = passwords;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getPhoneNo() {
        return PhoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        PhoneNo = phoneNo;
    }

    @Override
    public String toString() {
        return "User{" +
                "UserId=" + UserId +
                ", UserName='" + UserName + '\'' +
                ", Passwords='" + Passwords + '\'' +
                ", emailId='" + emailId + '\'' +
                ", PhoneNo='" + PhoneNo + '\'' +
                '}';
    }
}
