package com.niit;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;



public class JukeBoxImp {
    public static void main(String[] args) throws SQLException {
        String username=" ";
        UserImp user = new UserImp();
        SongImp song = new SongImp();
       PlaylistImp playlist = new PlaylistImp();
        Scanner scanner = new Scanner(System.in);
        List<Song> allSongs = new ArrayList<>();
        System.out.println(".....................");
        System.out.println("Welcome to Juke box");
        System.out.println(".....................");
        //int users = scanner.nextInt();
        System.out.println("1.Register user");
        System.out.println("2.Sign in");
        int users = scanner.nextInt();
        boolean b;
        if (users == 1) {
            user.registration();
        } else if (users == 2) {
            System.out.println("please enter the username and password to login");
            System.out.println("User name : ");
            scanner.nextLine();
             username= scanner.nextLine();
            System.out.println("user password : ");
            String password = scanner.nextLine();
            b = user.userLogin(username,password);
        }else if(user >1 || user<2 ){
            System.out.println("check operation ");
             break;
        }
        int again = 1;
        int repeat=1;
       int playlistagain=1;
        do {
            System.out.println("\nEnter the operation you want to perform:  \n1. Songs \n2. Search songs \n3. Playlist \n4. Exit");
            int select = scanner.nextInt();
            if (select == 1) {
                song.songInitialize();
                SimpleAudioPlayer ss = new SimpleAudioPlayer();
                ss.m1();
                ss.SongsPlay();
            } else if (select == 2) {

               do {
                    System.out.println("select song by");
                    System.out.println("1. Artist");
                    System.out.println("2. song name");
                    System.out.println("3. Album");
                    System.out.println("4. genre ");
                    System.out.println("5. Exit");
                    int searchsong = scanner.nextInt();
                    if (searchsong == 1) {
                        song.sortByArtist();
                        System.out.println("name of artist:");
                        String userr = scanner.nextLine();
                        String ArtistName = scanner.nextLine();
                        System.out.println("...............................................");
                        System.out.println("All songs by artist : " + ArtistName);
                        System.out.println("...............................................");
                        List<Song> listsong = song.songView();
                        List<Song> byArtistName = song.searchArtist(listsong, ArtistName.trim());
                        SimpleAudioPlayer ss = new SimpleAudioPlayer();
                        ss.m1();
                        ss.SongsPlay();
                    } else if (searchsong == 2) {
                        song.sortByName();
                        System.out.println("name of song name:");
                        String userr = scanner.nextLine();
                        String SongName = scanner.nextLine();
                        System.out.println("...............................................");
                        System.out.println("All songs by name : " + SongName);
                        System.out.println("...............................................");
                        List<Song> listsong = song.songView();
                        List<Song> bySongName = song.searchByName(listsong, SongName.trim());
                        SimpleAudioPlayer ss = new SimpleAudioPlayer();
                        ss.m1();
                        ss.SongsPlay();
                    } else if (searchsong == 3) {
                        song.sortByAlbum();
                        System.out.println("name of Album:");
                        String userr = scanner.nextLine();
                        String Album = scanner.nextLine();
                        System.out.println("...............................................");
                        System.out.println("All songs by album : " + Album);
                        System.out.println("...............................................");
                        List<Song> listsong = song.songView();
                        List<Song> byAlbum = song.searchAlbum(listsong, Album.trim());
                        SimpleAudioPlayer ss = new SimpleAudioPlayer();
                        ss.m1();
                        ss.SongsPlay();
                    } else if (searchsong == 4) {
                        song.sortByGenre();
                        System.out.println("name of genre:");
                        String userr = scanner.nextLine();
                        String genre = scanner.nextLine();
                        System.out.println("...............................................");
                        System.out.println("All songs by genre : " + genre);
                        System.out.println("...............................................");
                        List<Song> listsong = song.songView();
                        List<Song> byGenre = song.searchGenre(listsong, genre.trim());
                        SimpleAudioPlayer ss = new SimpleAudioPlayer();
                        ss.m1();
                        ss.SongsPlay();
                    } else if(searchsong == 5){
                       break;
                   }
                   System.out.println("do you want to repeat yes ==1 or no ==2");
                   again =scanner.nextInt();
                   //else
                   if (again == 2) {

                   }
                }while(again==1);
            } else if (select == 3) {
                do {
                    System.out.println("playlist");
                    System.out.println("1. Create Playlist");
                    System.out.println("2. Display playlist");
                    System.out.println("3. Add in playlist");
                    System.out.println("4. Exit");
                    System.out.println("enter the code");
                    int playlistOption = scanner.nextInt();
                    if (playlistOption == 1) {
                        System.out.println("create songs playlist");
                        playlist.playlistSongsInsertion();
                    } else if (playlistOption == 2) {
                        System.out.println("display songs playlist");
                        playlist.getUserID1(username);
                        playlist.displaySongsPlaylist();
                        System.out.println("enter the playlist id and song id");
                        int playlistId = scanner.nextInt();
                        playlist.displaySongsFromPlaylist(playlistId);
//                        SimpleAudioPlayer ss = new SimpleAudioPlayer();
//                        ss.m1();
//                        ss.SongsPlay();
                    } else if (playlistOption == 3) {
                        playlist.getUserID1(username);
                        playlist.displaySongsPlaylist();
                        System.out.println("enter the playlist code");
                        int playlistId = scanner.nextInt();
                        int stop = 0;
                        do {
                            song.songInitialize();
                            System.out.println("enter the song code");
                            int songId = scanner.nextInt();
                            playlist.addSongInPlaylist(playlistId, songId);
                            System.out.println("do you want to add more songs yes ==1 or no ==2");
                            stop = scanner.nextInt();
                            if (stop == 2) {
                                break;
                            }
                        } while (stop == 1);

                    }else if(playlistOption == 4){
                        break;
                    }
                    System.out.println("do you want to repeat yes ==1 or no ==2");
                    playlistagain =scanner.nextInt();
                    if (playlistagain  == 2) {
                    }
                }while (playlistagain ==1);
            }else if(select==4){
                System.out.println("Thank you for using Juke box");
                break;
            }
        }
            while (repeat == 1) ;
        }
    }

