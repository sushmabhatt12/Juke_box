package com.niit;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SongImp {
    MakeConnection connection = new MakeConnection();
    Song song;

    public List<Song> songInitialize() {
        List<Song> songList = new ArrayList<>();
        try {
            String SQL = "select * from songs";
            Statement statement = connection.createConnection().createStatement();
            ResultSet rs = statement.executeQuery(SQL);
            while (rs.next()) {
                int songId = rs.getInt(1);
                String songName = rs.getString(2);
                String artistName = rs.getString(3);
                String genre = rs.getString(4);
                String ablum = rs.getString(5);
                String timing = rs.getString(6);
                String paths = rs.getString(7);
                Song display = new Song(songId, songName, artistName, genre, ablum, timing, paths);
                songList.add(display);

            }
            System.out.println("......................................................................................................................");
            System.out.format("%-20s %-20s %-20s %-20s %-20s %-20s  %n","songId", "songName", "artistName", "genre", "album", "timing");
            System.out.println("......................................................................................................................");
            for(Song s:songList)
            {
                System.out.format("%-20s %-20s %-20s %-20s %-20s %-20s  %n",s.getUserId(),s.getSongName(),s.getArtistName(),s.getGenre(),s.getAlbum(),s.getTiming());
            }
            System.out.println("......................................................................................................................");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return songList;
    }
    public List<Song> songView() {
        List<Song> songList = new ArrayList<>();
        try {
            String SQL = "select * from songs";
            Statement statement = connection.createConnection().createStatement();
            ResultSet rs = statement.executeQuery(SQL);
            while (rs.next()) {
                int songId = rs.getInt(1);
                String songName = rs.getString(2);
                String artistName = rs.getString(3);
                String genre = rs.getString(4);
                String ablum = rs.getString(5);
                String timing = rs.getString(6);
                String paths = rs.getString(7);
                Song display = new Song(songId, songName, artistName, genre, ablum, timing, paths);
                songList.add(display);

            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return songList;
    }

    public List<Song> searchAlbum(List<Song> songList, String Album) {
        List<Song> listByAlbum = new ArrayList<>();
        System.out.println("......................................................................................................................");
        System.out.format("%-20s %-20s %-20s %-20s %-20s %-20s  %n","songId", "songName", "artistName", "genre", "album", "timing");
        System.out.println("......................................................................................................................");

        for (Song song : songList) {
            if (song.getAlbum().equalsIgnoreCase(Album)) {
                listByAlbum.add(song);
                {
                    System.out.format("%-20s %-20s %-20s %-20s %-20s %-20s  %n",song.getUserId(),song.getSongName(),song.getArtistName(),song.getGenre(),song.getAlbum(),song.getTiming());
                }
            }
            listByAlbum.sort((o1, o2) ->
            {
                return o1.getAlbum().compareToIgnoreCase(o2.getAlbum());
            });
        }
        System.out.println("......................................................................................................................");
        return listByAlbum;
    }

    public List<Song> searchGenre(List<Song> songList, String Genre) {
        List<Song> listByGenre = new ArrayList<>();
        System.out.println("......................................................................................................................");
        System.out.format("%-20s %-20s %-20s %-20s %-20s %-20s  %n","songId", "songName", "artistName", "genre", "album", "timing");
        System.out.println("......................................................................................................................");
        for (Song song : songList) {
            if (song.getGenre().equalsIgnoreCase(Genre)) {
                listByGenre.add(song);
                {
            System.out.format("%-20s %-20s %-20s %-20s %-20s %-20s  %n",song.getUserId(),song.getSongName(),song.getArtistName(),song.getGenre(),song.getAlbum(),song.getTiming());
        }
            }
            listByGenre.sort((o1, o2) ->
            {
                return o1.getGenre().compareToIgnoreCase(o2.getGenre());
            });
        }
        System.out.println("......................................................................................................................");

        return listByGenre;
    }

    public List<Song> searchArtist(List<Song> songList, String Artist) {
        List<Song> listByArtist = new ArrayList<>();
        System.out.println("......................................................................................................................");
        System.out.format("%-20s %-20s %-20s %-20s %-20s %-20s  %n","songId", "songName", "artistName", "genre", "album", "timing");
        System.out.println("......................................................................................................................");

        for (Song song : songList) {
            if (song.getArtistName().equalsIgnoreCase(Artist)) {
                listByArtist.add(song);
                {
                    System.out.format("%-20s %-20s %-20s %-20s %-20s %-20s  %n",song.getUserId(),song.getSongName(),song.getArtistName(),song.getGenre(),song.getAlbum(),song.getTiming());
                }
            }
            listByArtist.sort((o1, o2) ->
            {
                return o1.getArtistName().compareToIgnoreCase(o2.getArtistName());
            });
        }
        System.out.println("......................................................................................................................");

        return listByArtist;
    }

    public List<Song> searchByName(List<Song> songList, String Name) {
        List<Song> listByName = new ArrayList<>();
        System.out.println("......................................................................................................................");
        System.out.format("%-20s %-20s %-20s %-20s %-20s %-20s  %n","songId", "songName", "artistName", "genre", "album", "timing");
        System.out.println("......................................................................................................................");

        for (Song song : songList) {
            if (song.getSongName().equalsIgnoreCase(Name)) {
                listByName.add(song);
                {
                    System.out.format("%-20s %-20s %-20s %-20s %-20s %-20s  %n",song.getUserId(),song.getSongName(),song.getArtistName(),song.getGenre(),song.getAlbum(),song.getTiming());
                }
            }
            listByName.sort((o1, o2) ->
            {
                return o1.getSongName().compareToIgnoreCase(o2.getSongName());
            });
        }
        System.out.println("......................................................................................................................");

        return listByName;
    }
    public List<Song> getAllSongs(){
        List<Song> songsList = new ArrayList<>();
        try {
            String SQL = "select * from songs order by ArtistName ";
            Statement statement = connection.createConnection().createStatement();
            ResultSet rs = statement.executeQuery(SQL);
            while (rs.next()) {
                int songId = rs.getInt(1);
                String songName = rs.getString(2);
                String artistName = rs.getString(3);
                String genre = rs.getString(4);
                String ablum = rs.getString(5);
                String timing = rs.getString(6);
                String paths = rs.getString(7);
                Song display = new Song(songId, songName, artistName, genre, ablum, timing, paths);
                songsList.add(display);
            }
            System.out.println("...........................................................................................");
            System.out.format("%-20s %-20s %-20s   %n","songId", "songName", "artistName", "genre", "ablum", "timing");
            System.out.println("...........................................................................................");
            for(Song s:songsList)
            {
                System.out.format("%-20s %-20s %-20s   %n",s.getUserId(),s.getSongName(),s.getArtistName(),s.getGenre(),s.getAlbum(),s.getTiming());
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return songsList;
    }

    public List<Song> sortByArtist(){
        List<Song> songsList = new ArrayList<>();
        try {
            String SQL = "select * from songs order by ArtistName ";
            Statement statement = connection.createConnection().createStatement();
            ResultSet rs = statement.executeQuery(SQL);
            while (rs.next()) {
                int songId = rs.getInt(1);
                String songName = rs.getString(2);
                String artistName = rs.getString(3);
                String genre = rs.getString(4);
                String ablum = rs.getString(5);
                String timing = rs.getString(6);
                String paths = rs.getString(7);
                Song display = new Song(songId, songName, artistName, genre, ablum, timing, paths);
                songsList.add(display);
            }
            System.out.println(".........................................................");
            System.out.format("%-20s %-20s %-20s   %n","songId", "songName", "artistName", "genre", "ablum", "timing");
            System.out.println(".........................................................");
            for(Song s:songsList)
            {
                System.out.format("%-20s %-20s %-20s   %n",s.getUserId(),s.getSongName(),s.getArtistName(),s.getGenre(),s.getAlbum(),s.getTiming());
            }
            System.out.println(".........................................................");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return songsList;
    }

    public List<Song> sortByGenre(){
        List<Song> songsList = new ArrayList<>();
        try {
            String SQL = "select * from songs order by genre ";
            Statement statement = connection.createConnection().createStatement();
            ResultSet rs = statement.executeQuery(SQL);
            while (rs.next()) {
                int songId = rs.getInt(1);
                String songName = rs.getString(2);
                String artistName = rs.getString(3);
                String genre = rs.getString(4);
                String ablum = rs.getString(5);
                String timing = rs.getString(6);
                String paths = rs.getString(7);
                Song display = new Song(songId, songName, artistName, genre, ablum, timing, paths);
                songsList.add(display);
            }
            System.out.println(".........................................................");
            System.out.format("%-20s %-20s %-20s   %n","songId", "songName","genre");
            System.out.println(".........................................................");
            for(Song s:songsList)
            {
                System.out.format("%-20s %-20s %-20s   %n",s.getUserId(),s.getSongName(),s.getGenre());
            }
            System.out.println(".........................................................");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return songsList;
    }

    public List<Song> sortByName(){
        List<Song> songsList = new ArrayList<>();
        try {
            String SQL = "select * from songs order by SongName ";
            Statement statement = connection.createConnection().createStatement();
            ResultSet rs = statement.executeQuery(SQL);
            while (rs.next()) {
                int songId = rs.getInt(1);
                String songName = rs.getString(2);
                String artistName = rs.getString(3);
                String genre = rs.getString(4);
                String ablum = rs.getString(5);
                String timing = rs.getString(6);
                String paths = rs.getString(7);
                Song display = new Song(songId, songName, artistName, genre, ablum, timing, paths);
                songsList.add(display);
            }
            System.out.println(".........................................................");
            System.out.format("%-20s %-20s %-20s   %n","songId", "songName", "genre");
            System.out.println(".........................................................");
            for(Song s:songsList)

            {
                System.out.format("%-20s %-20s %-20s    %n",s.getUserId(),s.getSongName(),s.getGenre());
            }
            System.out.println(".........................................................");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return songsList;
    }
    public List<Song> sortByAlbum(){
        List<Song> songsList = new ArrayList<>();
        try {
            String SQL = "select * from songs order by ablum ";
            Statement statement = connection.createConnection().createStatement();
            ResultSet rs = statement.executeQuery(SQL);
            while (rs.next()) {
                int songId = rs.getInt(1);
                String songName = rs.getString(2);
                String artistName = rs.getString(3);
                String genre = rs.getString(4);
                String ablum = rs.getString(5);
                String timing = rs.getString(6);
                String paths = rs.getString(7);
                Song display = new Song(songId, songName, artistName, genre, ablum, timing, paths);
                songsList.add(display);
            }
            System.out.println(".........................................................");
            System.out.format("%-20s %-20s %-20s   %n","songId", "songName","ablum");
            System.out.println(".........................................................");
            for(Song s:songsList)
            {
                System.out.format("%-20s %-20s %-20s   %n",s.getUserId(),s.getSongName(),s.getAlbum());
            }
            System.out.println(".........................................................");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return songsList;
    }

}
