package com.niit;

public class PlaylistDetail {
    private int playlistId;
    private int SongId;

    public PlaylistDetail(int playlistId, int songId) {
        this.playlistId = playlistId;
        SongId = songId;
    }

    public int getPlaylistId() {
        return playlistId;
    }

    public void setPlaylistId(int playlistId) {
        this.playlistId = playlistId;
    }

    public int getSongId() {
        return SongId;
    }

    public void setSongId(int songId) {
        SongId = songId;
    }

    @Override
    public String toString() {
        return "PlaylistDetail{" +
                "playlistId=" + playlistId +
                ", SongId=" + SongId +
                '}';
    }
}
