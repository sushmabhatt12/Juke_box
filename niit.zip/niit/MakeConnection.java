package com.niit;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;

public class MakeConnection {

  public Connection  createConnection()
    {
        Connection connection=null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");  // load the driver
            connection = DriverManager.getConnection
                    ("jdbc:mysql://localhost:3306/jukebox",
                            "root", "root1234");
        }
        catch (ClassNotFoundException e)
        {
            System.out.println(e.getMessage());
        }
        catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }
        return connection;
    }
}

