package com.niit;

public class Song {
    private  int UserId;
    private String SongName;
    private String ArtistName ;
    private String genre;
    private String album;
    private String timing ;
    private String paths;

    public Song(int anInt, String string, String resultSetString, String setString, float aFloat, String s){

    }

    public Song(int userId,String songName, String artistName, String genre, String album, String timing, String paths) {
        this.UserId = userId;
        this.SongName = songName;
        this.ArtistName = artistName;
        this.genre = genre;
        this.album = album;
        this.timing = timing;
        this.paths = paths;
    }


    public String getSongName() {
        return SongName;
    }

    public void setSongName(String songName) {
        SongName = songName;
    }

    public String getArtistName() {
        return ArtistName;
    }

    public void setArtistName(String artistName) {
        ArtistName = artistName;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getAlbum() {
        return album;
    }

    public void setAlbum(String album) {
        this.album = album;
    }

    public String getTiming() {
        return timing;
    }

    public void setTiming(String timing) {
        this.timing = timing;
    }

    public String getPaths() {
        return paths;
    }

    public void setPaths(String paths) {
        this.paths = paths;
    }

    public int getUserId() {
        return UserId;
    }

    public void setUserId(int userId) {
        UserId = userId;
    }

//
//    @Override
//    public String toString() {
//        return
//
//                "" +
//                        "   " + UserId +
//                        "  " + SongName + '\'' +
//                        "   " + ArtistName + '\'' +
//                        "  " + genre + '\'' +
//                        "   " + album + '\'' +
//                        "  " + timing + '\''
//                        ;
//    }
}


