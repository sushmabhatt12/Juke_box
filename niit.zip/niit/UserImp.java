package com.niit;

import java.sql.*;
import java.util.Scanner;


public class UserImp {
    MakeConnection makeConnection = new MakeConnection();
    Connection connection = makeConnection.createConnection();
    Scanner scanner = new Scanner(System.in);
    public void registration(){
        try {
            String sql = "insert into Users ( UserId,UserName,passwords,emailId,PhoneNo)values(?,?,?,?,?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            System.out.println("please enter the user detail");
            System.out.println("user id");
            int userId = scanner.nextInt();
            System.out.println("User name ");
            String usrName = scanner.nextLine();
            String username = scanner.nextLine();
            System.out.println("user password");
            String password = scanner.nextLine();
            System.out.println("user email");
            String email = scanner.nextLine();
            System.out.println("user phone no");
            String phoneNo = scanner.nextLine();
            statement.setInt(1, userId);
            statement.setString(2, username);
            statement.setString(3, password);
            statement.setString(4, email);
            statement.setString(5, phoneNo);
            Integer userDetail = statement.executeUpdate();
            if (userDetail == 1) {
                System.out.println("user details successfully registered");
            } else {
                System.out.println(" user detail not registered");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public boolean userLogin(String username, String password){
    boolean check = true;
        try {
            String sql = "select * from Users where UserName=? and Passwords=?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1,username);
            statement.setString(2,password);
            ResultSet rs = statement.executeQuery();
            if(rs.next()) {
                    System.out.println("Successful Login");
                }
        else {
            check = false;
                    System.out.println("Incorrect detail ");
                }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            userLogin(username,password);
        }
        return check;
    }
}
