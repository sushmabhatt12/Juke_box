package com.niit;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class PlaylistImp {

    MakeConnection connection = new MakeConnection();
    Scanner scanner = new Scanner(System.in);

    public void playlistSongsInsertion() {
        try {
            Scanner sc = new Scanner(System.in);
            String sql = "insert into playlist(playlistId, playlistName, UserId) values(?,?,?);";
            PreparedStatement statement = connection.createConnection().prepareStatement(sql);
            //System.out.println("Enter Playlist Name");

            System.out.println("playlistId");
            int playlistId = scanner.nextInt();
            System.out.println("playlistName");
            String usrName = scanner.nextLine();
            String playlistName = scanner.nextLine();
            System.out.println("UserId");
            int UserId = scanner.nextInt();
            statement.setInt(1, playlistId);
            statement.setString(2, playlistName);
            statement.setInt(3, UserId);
            int display = statement.executeUpdate();
            if (display == 1) {
                System.out.println("Playlist successfully created ");
            } else {
                System.out.println("There is problem with playlist creation");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }
    int userIDLogIn;

    public int getUserID1(String Username) throws SQLException {
        int returnedUserID = 0;
        Statement s = connection.createConnection().createStatement();
//        System.out.println("User name");
//        String Name = scanner.nextLine();
        ResultSet rs = s.executeQuery("select UserId from Users where UserName='" +Username+ "';");
        while (rs.next()) {
            returnedUserID = rs.getInt(1);
        }
        userIDLogIn = returnedUserID;
        return returnedUserID;
    }


    int currentPlaylistID;

    public void getPlayListID(String Name) {
        try {
            PreparedStatement statement = connection.createConnection().prepareStatement("select playlistId from playlist where playlistName='" +Name+ "'");
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                currentPlaylistID = rs.getInt(1);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void addSongInPlaylist(int playlistId,int SongId){
        try {
            PreparedStatement ps = connection.createConnection().prepareStatement("insert into playlistdetail (playlistId,SongId) values(?,?);");
            ps.setInt(1, playlistId);// change it letter
            ps.setInt(2, SongId);
            int x = ps.executeUpdate();
            System.out.println(x);
    } catch(SQLException e) {
        System.out.println(e.getMessage());
    }
    }

    public void displaySongsFromPlaylist(int playlistID){
        try{
        PreparedStatement ps = connection.createConnection().prepareStatement("select * from songs where SongId in(select SongId from  playlistdetail where playlistID=?)");

      ps.setInt(1,playlistID);
        ResultSet rs = ps.executeQuery();
//        boolean b = rs.next();
//        if(!rs.next()){
//            System.out.println("Playlist is Empty with ID "+playlistID);
//        }else {
            while (rs.next()) {
                System.out.format("%-30s %-30s %-30s %-30s %n", rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4));
            }

            SimpleAudioPlayer ss = new SimpleAudioPlayer();
            ss.m1();
            ss.SongsPlay();
      //  }

    } catch(SQLException e) {
        System.out.println(e.getMessage());
    }
    }
    public void displaySongsPlaylist() {
        try {
            PreparedStatement ps = connection.createConnection().prepareStatement("select * from playlist where UserId = ? ");
            ps.setInt(1, userIDLogIn);
            ResultSet rs = ps.executeQuery();
            System.out.format("%-30s %-30s %-30s %n", "playlistId", "playlistName", "UserId");
            while (rs.next()) {
                System.out.format("%-30s %-30s %-30s %n", rs.getInt(1), rs.getString(2),rs.getInt(3));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}




