package com.niit;

import java.sql.Connection;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;


public class UserTest {
    UserImp userImp = new UserImp();;
    MakeConnection makeConnection =new MakeConnection();
    Connection connection ;
 PlaylistImp playlistImp = new PlaylistImp();


@Test
public void  checkUserLogin()
        {
            connection = makeConnection.createConnection();
            User user = new User();
            UserImp userImp1 =new UserImp();
            String username = "ram";
            String password = "ram1323";
           boolean output = userImp.userLogin(username,password);
               assertTrue(output);
           }

    @Test
    public void  checkUserLoginUnsuccessful()
    {
        connection = makeConnection.createConnection();
        User user = new User();
        UserImp userImp1 =new UserImp();
        String username = "sam";
        String password = "ram1323";
        boolean output = userImp.userLogin(username,password);
        assertFalse(output);
    }

@Test
public void CheckAllSongs()
        {
        SongImp songImp = new SongImp();
        Song song = new Song(1,"Muskaanein","suman sridhar","jazz","Talaash","'3.03","E:\\Project jukeBox\\songs\\Muskaanein.wav");
        List<Song> list = songImp.songView();
        String expected =song.getSongName();
            assertEquals(expected, list.get(0).getSongName());

        }





















//        SongImp songImp = new SongImp();
//        Song song = new Song();
//        List<Song> list = songImp.searchAlbum(songImp.songView(),"paagal");
//        String expected =
//        assertEquals(expected, list);

    }

//    @Test
//    public void checkdisplaySongsPlaylist(){
//    Playlist playlist = new Playlist();
//    LL= new
//
//
//    public void displaySongsFromPlaylist(int playlistID)
//}

//    @Test
//    public void givenInputAppleShouldReturnAllAppleMobile()
//    {
//        mobileStore = new MobileStore();
//        mobileStore.readMobileData("mobile.csv");
//        List brand = mobileStore.findPhoneByBrand("Apple");
//        assertEquals(3,brand.size());

  //}